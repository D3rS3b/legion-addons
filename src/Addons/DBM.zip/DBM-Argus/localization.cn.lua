-- Mini Dragon(projecteurs@gmail.com)
-- 夏一可
-- Blizzard Entertainment
-- Last update: 2017/07/03

if GetLocale() ~= "zhCN" then return end
local L

-----------------------
-- Inquisitor Meto --
-----------------------
L= DBM:GetModLocalization(2012)

-----------------------
-- Occularus --
-----------------------
L= DBM:GetModLocalization(2013)

-----------------------
-- Sotanathor --
-----------------------
L= DBM:GetModLocalization(2014)

-----------------------
-- Mistress Alluradel --
-----------------------
L= DBM:GetModLocalization(2011)

-----------------------
-- Matron Folnuna --
-----------------------
L= DBM:GetModLocalization(2010)

-----------------------
-- Pit Lord Vilemus --
-----------------------
L= DBM:GetModLocalization(2015)
