﻿local _,L = ...

if GetLocale()=="esMX" then

end
