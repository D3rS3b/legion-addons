# SpartanUI |CFF0070DDCore

## [4.4.11](https://github.com/Wutname1/SpartanUI/tree/4.4.11) (2018-06-27)
[Full Changelog](https://github.com/Wutname1/SpartanUI/compare/4.4.9...4.4.11)

- Packager Update  
- LUA Error fix in oUF Module  
- Packager IDs updated  
- Packager Update  
- Artifact bar updates  
