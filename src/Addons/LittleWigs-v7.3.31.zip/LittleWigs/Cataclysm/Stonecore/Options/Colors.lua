
BigWigs:AddColors("Corborus", {
	[86881] = "Personal",
	["burrow"] = {"Attention","Important"},
})

BigWigs:AddColors("Slabhide", {
	[80801] = "Personal",
	[92265] = "Important",
})

BigWigs:AddColors("Ozruk", {
	[78903] = "Urgent",
	[78939] = "Important",
	[80467] = "Attention",
	[92426] = "Important",
})

BigWigs:AddColors("High Priestess Azil", {
	[79050] = "Important",
	[79345] = {"Attention","Personal"},
})
