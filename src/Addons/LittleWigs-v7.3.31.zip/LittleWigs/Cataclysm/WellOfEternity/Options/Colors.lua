
BigWigs:AddColors("Peroth'arn", {
	[105442] = {"Attention","Personal"},
	[105493] = {"Attention","Personal"},
	[105544] = {"Important","Personal"},
	["eyes"] = "Positive",
})

BigWigs:AddColors("Queen Azshara", {
	[-3969] = {"Positive","Urgent"},
	[-3968] = "Attention",
})

BigWigs:AddColors("Mannoroth and Varo'then", {
	[-4287] = "Attention",
})
