
BigWigs:AddColors("Akil'zon", {
	[43648] = {"Important","Personal"},
	[97318] = {"Important","Personal"},
})

BigWigs:AddColors("Nalorakk", {
	[42398] = {"Attention","Personal"},
	[42402] = {"Personal","Urgent"},
	["stages"] = "Important",
})

BigWigs:AddColors("Jan'alai", {
	[-2625] = "Attention",
	[-2622] = "Urgent",
	[97497] = {"Important","Personal"},
})

BigWigs:AddColors("Halazzi", {
	[43139] = "Important",
	[43302] = "Urgent",
	[43303] = {"Attention","Personal"},
	[97499] = "Urgent",
	["stages"] = {"Attention","Positive"},
})

BigWigs:AddColors("Hex Lord Malacrass", {
	[43383] = "Important",
	[43421] = {"Personal","Urgent"},
	[43431] = "Urgent",
	[43451] = "Urgent",
	[43501] = {"Attention","Personal"},
	[43548] = "Urgent",
})

BigWigs:AddColors("Daakara", {
	[17207] = "Urgent",
	[43093] = {"Attention","Personal"},
	[43095] = "Attention",
	[43150] = {"Important","Personal"},
	["stages"] = "Important",
})
