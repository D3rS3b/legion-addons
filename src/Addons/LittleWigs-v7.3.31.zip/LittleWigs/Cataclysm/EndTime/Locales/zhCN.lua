local L = BigWigs:NewBossLocale("Echo of Baine", "zhCN")
if not L then return end
if L then
	L.totemDrop = "图腾已掉落"
	L.totemThrow = "%s已扔图腾"
end
