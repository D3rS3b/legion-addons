local L = BigWigs:NewBossLocale("Echo of Baine", "ptBR")
if not L then return end
if L then
	 L.totemDrop = "Totem dropado"
	 L.totemThrow = "Totem lançado por %s"
end
