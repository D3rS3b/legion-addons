
BigWigs:AddColors("Rom'ogg Bonecrusher", {
	[75272] = {"Attention","Personal"},
	[75539] = {"Attention","Important"},
	[75543] = "Urgent",
})

BigWigs:AddColors("Corla, Herald of Twilight", {
	[75697] = {"Personal","Positive"},
	[75823] = {"Important","Personal","Urgent"},
})

BigWigs:AddColors("Karsh Steelbender", {
	[75842] = "Attention",
	[75846] = {"Important","Personal"},
})

BigWigs:AddColors("Beauty", {
	[76028] = {"Attention","Personal"},
	[76031] = {"Personal","Urgent"},
	[76628] = "Personal",
})

BigWigs:AddColors("Ascendant Lord Obsidius", {
	[-2385] = {"Attention","Urgent"},
	[76188] = {"Important","Personal"},
	[76189] = {"Attention","Personal"},
})
