
BigWigs:AddSounds("General Umbriss", {
	[74670] = "Alert",
	[74853] = "Long",
})

BigWigs:AddSounds("Forgemaster Throngus", {
	[74908] = "Alert",
	[74976] = "Long",
	[74981] = "Alert",
	[74987] = "Alarm",
	[75007] = "Alert",
})

BigWigs:AddSounds("Drahga Shadowburner", {
	[75218] = "Alarm",
	[90950] = "Long",
})

BigWigs:AddSounds("Erudax", {
	[75664] = "Alert",
	[75755] = "Alarm",
	[75763] = "Warning",
})
