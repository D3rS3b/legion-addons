
BigWigs:AddColors("General Umbriss", {
	[74634] = "Urgent",
	[74670] = {"Important","Personal"},
	[74846] = {"Attention","Personal"},
	[74853] = "Attention",
})

BigWigs:AddColors("Forgemaster Throngus", {
	[74908] = "Important",
	[74976] = "Personal",
	[74981] = "Important",
	[74987] = "Personal",
	[75007] = "Important",
	[75056] = {"Personal","Urgent"},
})

BigWigs:AddColors("Drahga Shadowburner", {
	[75218] = "Attention",
	[90950] = "Important",
})

BigWigs:AddColors("Erudax", {
	[75664] = "Urgent",
	[75755] = "Important",
	[75763] = "Important",
	["summon"] = "Attention",
})
