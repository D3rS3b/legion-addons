local L = BigWigs:NewBossLocale("Erudax", "esES") or BigWigs:NewBossLocale("Erudax", "esMX")
if not L then return end
if L then
	--L.summon = "Summon Faceless Corruptor"
	--L.summon_desc = "Warn when Erudax summons a Faceless Corruptor"
	--L.summon_message = "Faceless Corruptor Summoned"
	--L.summon_trigger = "summons a"
end
