local L = BigWigs:NewBossLocale("Erudax", "koKR")
if not L then return end
if L then
	L.summon = "얼굴 없는 타락자 소환"
	L.summon_desc = "에루닥스가 얼굴 없는 타락자를 소환하면 경보"
	L.summon_message = "얼굴 없는 타락자 소환됨"
	L.summon_trigger = "가 얼굴 없는 수호자를 소환합니다!"
end
