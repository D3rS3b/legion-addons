
BigWigs:AddColors("General Husam", {
	[83113] = {"Attention","Personal"},
	[83445] = "Important",
	[91263] = "Urgent",
})

BigWigs:AddColors("Lockmaw", {
	[81630] = {"Attention","Personal"},
	[81690] = {"Important","Personal"},
	[84784] = "Urgent",
})

BigWigs:AddColors("High Prophet Barim", {
	[82506] = "Important",
	[82622] = "Personal",
	[88814] = {"Attention","Personal"},
})

BigWigs:AddColors("Siamat", {
	["servant"] = "Important",
	["stages"] = {"Neutral","Positive"},
})
