local L = BigWigs:NewBossLocale("Siamat", "ptBR")
if not L then return end
if L then
	L.servant = "Sumonar Serviçal"
	L.servant_desc = "Avisa quando um Serviçal de Siamat é sumonado."
end
