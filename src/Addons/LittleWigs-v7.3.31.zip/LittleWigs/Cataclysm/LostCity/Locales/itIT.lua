local L = BigWigs:NewBossLocale("Siamat", "itIT")
if not L then return end
if L then
	--L.servant = "Summon Servant"
	--L.servant_desc = "Warn when a Servant of Siamat is summoned."
end
