
BigWigs:AddColors("High Priest Venoxis", {
	[96466] = "Urgent",
	[96477] = {"Personal","Urgent"},
	[96509] = "Important",
	[96653] = "Positive",
	[96842] = "Important",
})

BigWigs:AddColors("Bloodlord Mandokir", {
	[96684] = {"Attention","Personal"},
	[96724] = "Attention",
	[96740] = "Important",
	[96776] = "Attention",
	[96800] = "Important",
})

BigWigs:AddColors("High Priestess Kilnara", {
	[-2702] = "Important",
	[96423] = {"Attention","Personal"},
	[96435] = "Important",
	[96457] = "Important",
	[96592] = {"Attention","Personal"},
	["stages"] = "Attention",
})

BigWigs:AddColors("Zanzil", {
	[96316] = {"Attention","Important","Personal"},
	[96338] = "Attention",
	[96914] = "Attention",
})

BigWigs:AddColors("Jin'do the Godbreaker", {
	[-2910] = {"Important","Personal"},
	[97170] = "Important",
	[97172] = {"Attention","Important"},
	["stages"] = "Important",
})
