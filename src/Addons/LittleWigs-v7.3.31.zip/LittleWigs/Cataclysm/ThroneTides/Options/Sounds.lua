
BigWigs:AddSounds("Mindbender Ghur'sha", {
	[76207] = "Alert",
	[76230] = "Alarm",
})

BigWigs:AddSounds("Ozumat", {
	["stages"] = "Info",
})
