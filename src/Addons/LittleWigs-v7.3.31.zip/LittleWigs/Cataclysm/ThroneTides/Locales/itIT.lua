local L = BigWigs:NewBossLocale("Ozumat", "itIT")
if not L then return end
if L then
	--L.custom_on_autotalk = "Autotalk"
	--L.custom_on_autotalk_desc = "Instantly selects the gossip option to start the fight."
end
