
BigWigs:AddColors("Aqu'sirr", {
	[264101] = "yellow",
	[264166] = {"orange","Personal"},
	[264560] = {"Personal","yellow"},
	[264903] = "cyan",
	[265001] = "orange",
})

BigWigs:AddColors("Tidesage Coucil", {
	[267818] = "yellow",
	[267891] = {"cyan","green"},
	[267899] = "yellow",
	[267905] = "cyan",
})

BigWigs:AddColors("Lord Stormsong", {
	[268347] = "yellow",
	[269097] = "orange",
	[269131] = {"Personal","red"},
})

BigWigs:AddColors("Vol'zith the Whisperer", {
	[267037] = {"cyan","Personal"},
	[267360] = "red",
	[267385] = "orange",
	[269399] = "yellow",
})
