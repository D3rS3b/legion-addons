
BigWigs:AddSounds("Aqu'sirr", {
	[264101] = "alert",
	[264166] = "warning",
	[264560] = "alarm",
	[264903] = "long",
	[265001] = "alarm",
})

BigWigs:AddSounds("Tidesage Coucil", {
	[267818] = "alert",
	[267891] = {"info","long"},
	[267899] = "alert",
	[267905] = "long",
})

BigWigs:AddSounds("Lord Stormsong", {
	[268347] = "alert",
	[269097] = "Alarm",
	[269131] = "Warning",
})

BigWigs:AddSounds("Vol'zith the Whisperer", {
	[267037] = "info",
	[267360] = "long",
	[267385] = "Alarm",
	[269399] = "alert",
})
