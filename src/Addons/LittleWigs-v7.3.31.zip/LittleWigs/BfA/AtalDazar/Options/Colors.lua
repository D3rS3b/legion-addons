
BigWigs:AddColors("Priestess Alun'za", {
	[255558] = {"blue","green"},
	[255577] = "red",
	[255579] = "yellow",
	[255582] = {"orange","Personal"},
	[258709] = "blue",
})

BigWigs:AddColors("Vol'kaal", {
	[250241] = "green",
	[250258] = "yellow",
	[250585] = "blue",
	[259572] = "red",
})

BigWigs:AddColors("Rezan", {
	[255371] = "red",
	[255434] = "yellow",
	[257407] = {"orange","Personal"},
})

BigWigs:AddColors("Yazma", {
	[249919] = "yellow",
	[249923] = {"Personal","red"},
	[250036] = "blue",
	[250050] = "yellow",
	[250096] = "orange",
})

BigWigs:AddColors("Atal'Dazar Trash", {
	[252687] = {"orange","Personal"},
	[252781] = {"blue","Personal"},
	[253721] = "yellow",
	[255041] = "orange",
	[255567] = "yellow",
	[256849] = "orange",
	[260666] = "yellow",
})
