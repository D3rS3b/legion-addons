
BigWigs:AddColors("Heartsbane Triad", {
	[260703] = {"orange","Personal"},
	[260741] = "orange",
	[260773] = "red",
	[260805] = {"cyan","Personal"},
	[260907] = {"orange","Personal"},
})

BigWigs:AddColors("Soulbound Goliath", {
	[260508] = "yellow",
	[260512] = {"Personal","yellow"},
	[260541] = {"cyan","Personal"},
	[260551] = "orange",
	[260569] = {"blue","Personal"},
})

BigWigs:AddColors("Raal the Gluttonous", {
	[264694] = {"blue","orange"},
	[264734] = "orange",
	[264923] = "red",
	[264931] = "yellow",
	[265002] = "orange",
})

BigWigs:AddColors("Lord and Lady Waycrest", {
	[261438] = "yellow",
	[261440] = {"Personal","red"},
	[261447] = {"cyan","Personal"},
	[268306] = "orange",
})

BigWigs:AddColors("Gorak Tul", {
	[266181] = "red",
	[266198] = "green",
	[266225] = "orange",
	[266266] = "yellow",
})

BigWigs:AddColors("Waycrest Manor Trash", {
	[263905] = "yellow",
	[263943] = {"orange","Personal"},
	[263959] = "red",
	[263961] = "yellow",
	[264038] = "orange",
	[264050] = "yellow",
	[264105] = {"orange","Personal","yellow"},
	[264150] = "red",
	[264390] = "red",
	[264396] = "yellow",
	[264456] = "yellow",
	[264520] = "yellow",
	[264525] = "red",
	[264556] = {"blue","Personal"},
	[265346] = "orange",
	[265352] = "red",
	[265368] = "cyan",
	[265407] = "orange",
	[265741] = "yellow",
	[265759] = "orange",
	[265760] = "red",
	[265876] = "red",
	[265880] = {"orange","Personal"},
	[265881] = "yellow",
	[271174] = "yellow",
})
