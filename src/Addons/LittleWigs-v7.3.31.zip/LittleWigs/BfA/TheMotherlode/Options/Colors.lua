
BigWigs:AddColors("Coin-Operated Crowd Pummeler", {
	[256493] = {"blue","green","Personal"},
	[257337] = "orange",
	[262347] = "yellow",
	[269493] = "cyan",
})

BigWigs:AddColors("Tik'ali", {
	[257582] = {"Personal","red"},
	[257593] = "cyan",
	[258622] = "orange",
	[271698] = "yellow",
})

BigWigs:AddColors("Rixxa Fluxflame", {
	[259853] = {"orange","Personal"},
	[260669] = "yellow",
	[270042] = "red",
})

BigWigs:AddColors("Mogul Razzdunk", {
	[260280] = "yellow",
	[260811] = "red",
	[271456] = "orange",
	["stages"] = "cyan",
})
