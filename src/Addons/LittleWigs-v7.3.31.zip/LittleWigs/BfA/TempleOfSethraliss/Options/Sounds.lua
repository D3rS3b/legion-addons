
BigWigs:AddSounds("Adderis and Aspix", {
	[263246] = "info",
	[263371] = "warning",
	[263573] = "alert",
})

BigWigs:AddSounds("Merektha", {
	[263912] = "alert",
	[263927] = "alarm",
	[264194] = "long",
	[264239] = "info",
})

BigWigs:AddSounds("Galvazzt", {
	[266512] = "Warning",
	[266923] = {"alarm","info"},
})

BigWigs:AddSounds("Avatar of Sethraliss", {
	[268024] = "alert",
	[273677] = "warning",
})
