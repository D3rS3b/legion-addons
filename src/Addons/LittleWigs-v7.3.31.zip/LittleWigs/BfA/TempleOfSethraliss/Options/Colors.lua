
BigWigs:AddColors("Adderis and Aspix", {
	[263246] = {"cyan","Personal"},
	[263371] = {"orange","Personal"},
	[263573] = "yellow",
})

BigWigs:AddColors("Merektha", {
	[263912] = "yellow",
	[263927] = "blue",
	[264194] = "orange",
	[264239] = "cyan",
})

BigWigs:AddColors("Galvazzt", {
	[266512] = "red",
	[266923] = {"cyan","orange","Personal"},
})

BigWigs:AddColors("Avatar of Sethraliss", {
	[268024] = "yellow",
	[273677] = "red",
})
