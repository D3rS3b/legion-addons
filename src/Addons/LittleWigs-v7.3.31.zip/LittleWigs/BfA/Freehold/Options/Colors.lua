
BigWigs:AddColors("Skycap'n Kragg", {
	[255952] = "yellow",
	[256016] = "blue",
	[256060] = "red",
	[256106] = "yellow",
	["stages"] = "cyan",
})

BigWigs:AddColors("Council o' Captains", {
	[256589] = "orange",
	[258338] = "yellow",
	[258381] = "red",
})

BigWigs:AddColors("Ring of Booty", {
	[256358] = "yellow",
	[256405] = "red",
	[256489] = "cyan",
})

BigWigs:AddColors("Harlan Sweete", {
	[257278] = "yellow",
	[257305] = {"blue","orange"},
	[257314] = {"Personal","yellow"},
	[257316] = "red",
	["stages"] = "cyan",
})

BigWigs:AddColors("Freehold Trash", {
	[257272] = "blue",
	[257397] = {"cyan","Personal","yellow"},
	[257426] = "red",
	[257437] = {"blue","Personal"},
	[257732] = "orange",
	[257736] = "orange",
	[257739] = {"blue","Personal"},
	[257756] = "orange",
	[257775] = {"blue","Personal"},
	[257829] = {"cyan","green","Personal"},
	[257870] = "yellow",
	[257899] = {"red","yellow"},
	[257904] = "yellow",
	[257908] = {"blue","Personal"},
	[258181] = "orange",
	[258199] = "yellow",
	[258323] = {"blue","Personal"},
	[258672] = "orange",
	[258777] = "yellow",
	[272402] = {"orange","Personal"},
	[274383] = "yellow",
	[274400] = {"Personal","red"},
	[274507] = {"blue","Personal","red"},
	[274555] = {"blue","Personal"},
})
