
BigWigs:AddColors("Elder Leaxa", {
	[260879] = "orange",
	[260894] = "yellow",
	[264603] = {"cyan","green","red"},
})

BigWigs:AddColors("Infested Crawg", {
	[260292] = "yellow",
	[260793] = "red",
})

BigWigs:AddColors("Sporecaller Zancha", {
	[259718] = {"orange","Personal"},
	[259732] = "red",
	[259830] = "cyan",
	[272457] = "yellow",
})

BigWigs:AddColors("Unbound Abomination", {
	[269310] = "green",
	[269843] = "red",
	["stages"] = "cyan",
})

BigWigs:AddColors("Underrot Trash", {
	[265019] = {"blue","Personal"},
	[265081] = "red",
	[265089] = "orange",
	[265433] = "orange",
	[265487] = "red",
	[265523] = "yellow",
	[265540] = "yellow",
	[265568] = {"blue","cyan","Personal"},
	[265668] = "yellow",
	[265687] = "blue",
	[266105] = "orange",
	[266107] = {"blue","Personal"},
	[266209] = "cyan",
	[272183] = "yellow",
	[272592] = "cyan",
	[272609] = "orange",
})
