local L = BigWigs:NewBossLocale("Maw of Souls Trash", "esES") or BigWigs:NewBossLocale("Maw of Souls Trash", "esMX")
if not L then return end
if L then
	L.soulguard = "Guardián de almas calado"
	L.champion = "Campeón Helarjar"
	L.mariner = "Marino de la Guardia Nocturna"
	L.swiftblade = "Hojágil maldecido por el mar"
	L.mistmender = "Curanieblas maldecida por el mar"
	L.mistcaller = "Clamaneblina Helarjar"
	L.skjal = "Skjal"
end
