local L = BigWigs:NewBossLocale("Maw of Souls Trash", "zhTW")
if not L then return end
if L then
	--L.soulguard = "Waterlogged Soul Guard"
	--L.champion = "Helarjar Champion"
	--L.mariner = "Night Watch Mariner"
	--L.swiftblade = "Seacursed Swiftblade"
	--L.mistmender = "Seacursed Mistmender"
	--L.mistcaller = "Helarjar Mistcaller"
	--L.skjal = "Skjal"
end
