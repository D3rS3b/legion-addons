
BigWigs:AddColors("Ymiron", {
	[193211] = "Urgent",
	[193364] = "Important",
	[193566] = "Attention",
	[193977] = "Attention",
})

BigWigs:AddColors("Harbaron", {
	[194216] = "Urgent",
	[194231] = "Attention",
	[194325] = {"Important","Personal"},
	[194668] = "Personal",
})

BigWigs:AddColors("Helya", {
	[185539] = "Personal",
	[196947] = "Neutral",
	[197262] = {"Attention","Personal"},
	[198495] = "Important",
	[202088] = "Urgent",
	[227233] = "Urgent",
	["destructor_tentacle"] = "Attention",
	["stages"] = "Neutral",
})

BigWigs:AddColors("Maw of Souls Trash", {
	[192019] = "Attention",
	[194615] = "Attention",
	[194657] = "Urgent",
	[195293] = "Urgent",
	[198324] = {"Important","Personal"},
	[198405] = {"Attention","Important"},
	[199514] = {"Personal","Urgent"},
	[199589] = {"Personal","Urgent"},
	[216197] = "Urgent",
})
