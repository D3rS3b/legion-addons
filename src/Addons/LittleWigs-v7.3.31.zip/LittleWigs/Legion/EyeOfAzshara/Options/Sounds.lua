
BigWigs:AddSounds("Warlord Parjesh", {
	[191900] = "Alert",
	[192053] = "Alarm",
	[192072] = "Info",
	[192094] = "Warning",
	[192131] = "Alarm",
	[196563] = "Info",
	[197064] = "Alert",
	[197502] = {"Long","Warning"},
})

BigWigs:AddSounds("Lady Hatecoil", {
	[193597] = "Warning",
	[193611] = "Alert",
	[193698] = "Alarm",
	["blob"] = "Info",
})

BigWigs:AddSounds("Serpentrix", {
	[191855] = "Alarm",
	[191873] = "Long",
})

BigWigs:AddSounds("King Deepbeard", {
	[193018] = "Warning",
	[193051] = "Long",
	[193093] = "Info",
	[193152] = "Alert",
})

BigWigs:AddSounds("Wrath of Azshara", {
	[192617] = "Warning",
	[192675] = "Alert",
	[192706] = "Alarm",
	[192985] = "Long",
	[197365] = "Alarm",
})

BigWigs:AddSounds("Eye of Azshara Trash", {
	[195046] = "Alarm",
	[195109] = "Alarm",
	[195129] = {"Info","Warning"},
	[195284] = "Long",
	[196027] = "Alarm",
	[196127] = "Long",
	[196870] = "Long",
	[197105] = "Info",
	[225089] = "Warning",
})
