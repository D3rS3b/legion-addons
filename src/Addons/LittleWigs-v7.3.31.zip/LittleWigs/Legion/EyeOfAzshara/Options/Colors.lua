
BigWigs:AddColors("Warlord Parjesh", {
	[191900] = "Attention",
	[192053] = "Personal",
	[192072] = "Attention",
	[192094] = {"Important","Personal"},
	[192131] = {"Important","Personal"},
	[196563] = "Attention",
	[197064] = "Urgent",
	[197502] = "Positive",
})

BigWigs:AddColors("Lady Hatecoil", {
	[193597] = "Urgent",
	[193611] = "Attention",
	[193698] = "Personal",
	[196610] = "Positive",
	["blob"] = "Important",
})

BigWigs:AddColors("Serpentrix", {
	[191855] = {"Important","Personal"},
	[191873] = "Attention",
})

BigWigs:AddColors("King Deepbeard", {
	[193018] = "Personal",
	[193051] = "Attention",
	[193093] = "Urgent",
	[193152] = {"Important","Personal"},
})

BigWigs:AddColors("Wrath of Azshara", {
	[192617] = "Attention",
	[192675] = "Urgent",
	[192706] = {"Important","Personal"},
	[192985] = "Positive",
	[197365] = {"Important","Personal"},
})

BigWigs:AddColors("Eye of Azshara Trash", {
	[195046] = "Attention",
	[195109] = "Attention",
	[195129] = "Important",
	[195284] = "Attention",
	[196027] = "Attention",
	[196127] = "Attention",
	[196870] = "Attention",
	[197105] = {"Attention","Personal"},
	[225089] = "Urgent",
})
