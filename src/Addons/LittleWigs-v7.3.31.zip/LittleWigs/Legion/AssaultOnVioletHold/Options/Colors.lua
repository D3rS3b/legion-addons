
BigWigs:AddColors("Shivermaw", {
	[201354] = "Urgent",
	[201355] = "Urgent",
	[201379] = "Attention",
	[201672] = "Important",
	[201960] = "Neutral",
	[202062] = "Important",
})

BigWigs:AddColors("Thalena", {
	[202779] = {"Personal","Positive"},
	[202947] = "Personal",
	[203381] = "Attention",
})

BigWigs:AddColors("Festerface", {
	[201598] = "Important",
	[201729] = "Urgent",
})

BigWigs:AddColors("Millificent Manastorm", {
	[201159] = {"Personal","Urgent"},
	[201240] = "Attention",
	[201392] = "Important",
	[201572] = "Neutral",
})

BigWigs:AddColors("Kaahrj", {
	[201146] = {"Personal","Urgent"},
	[201148] = "Attention",
	[201153] = "Important",
})

BigWigs:AddColors("Anub'esset", {
	[201863] = "Urgent",
	[202217] = {"Attention","Personal"},
	[202341] = {"Important","Personal"},
	[202480] = "Personal",
	[202485] = "Personal",
})

BigWigs:AddColors("Saelorn", {
	[202306] = {"Personal","Urgent"},
	[202414] = {"Attention","Personal"},
	[202473] = "Important",
})

BigWigs:AddColors("Fel Lord Betrug", {
	[202328] = "Urgent",
	[203641] = "Important",
	[205233] = {"Important","Personal","Positive"},
	[210879] = {"Attention","Personal"},
})

BigWigs:AddColors("Assault on Violet Hold Trash", {
	[204140] = "Important",
	[204608] = {"Personal","Urgent"},
	[204876] = "Important",
	[204901] = "Important",
	[205088] = "Important",
})
