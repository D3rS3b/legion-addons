
BigWigs:AddColors("Archdruid Glaidalis", {
	[196376] = {"Attention","Personal"},
	[198379] = "Important",
	[198408] = "Personal",
})

BigWigs:AddColors("Oakheart", {
	[204574] = "Attention",
	[204646] = {"Personal","Urgent"},
	[204666] = "Important",
	[204667] = "Important",
})

BigWigs:AddColors("Dresaron", {
	[191325] = "Attention",
	[199345] = "Important",
	[199460] = "Personal",
})

BigWigs:AddColors("Shade of Xavius", {
	[200050] = "Attention",
	[200185] = {"Personal","Urgent"},
	[200238] = {"Important","Personal"},
	[200289] = {"Attention","Personal"},
})

BigWigs:AddColors("Darkheart Thicket Trash", {
	[200580] = "Urgent",
	[200658] = "Attention",
	[200684] = {"Important","Personal"},
	[200768] = "Urgent",
	[201226] = "Urgent",
	[201272] = "Urgent",
	[201399] = "Attention",
	[218759] = "Personal",
	[225562] = "Urgent",
})
