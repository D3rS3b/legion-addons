local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "frFR")
if not L then return end
if L then
	L.ruiner = "Dévastateur âmeffroi"
	L.poisoner = "Empoisonneur âmeffroi"
	L.razorbeak = "Bec-rasoir affolé"
	L.grizzly = "Grizzly peau-putride"
	L.fury = "Fureur sang-vicié"
	L.imp = "Diablotin brûle-effroi"
end
