local L = BigWigs:NewBossLocale("Darkheart Thicket Trash", "koKR")
if not L then return end
if L then
	L.ruiner = "공포영혼 파멸자"
	L.poisoner = "공포영혼 독살자"
	L.razorbeak = "광기 어린 뾰족부리"
	L.grizzly = "고름가죽 불곰"
	L.fury = "피로 물든 격노"
	L.imp = "공포화염 임프"
end
