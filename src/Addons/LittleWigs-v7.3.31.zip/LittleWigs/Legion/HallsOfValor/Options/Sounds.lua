
BigWigs:AddSounds("Hymdall", {
	[191284] = "Long",
	[193092] = "Info",
	[193235] = {"Alarm","Alert"},
})

BigWigs:AddSounds("Hyrja", {
	[191976] = "Alarm",
	[192018] = "Alert",
	[192048] = "Alarm",
	[192307] = "Long",
	[200901] = "Long",
})

BigWigs:AddSounds("Fenryr", {
	[196543] = "Alert",
	[196838] = "Warning",
	[197556] = "Info",
})

BigWigs:AddSounds("God-King Skovald", {
	[193659] = "Alarm",
	[193668] = "Warning",
	[193702] = "Alarm",
	[193826] = "Long",
})

BigWigs:AddSounds("Odyn", {
	[197961] = {"Alarm","Warning"},
	[198077] = "Alert",
	[198263] = "Long",
	[200988] = "Alert",
	["warmup"] = "Info",
})

BigWigs:AddSounds("Halls of Valor Trash", {
	[191508] = "Alarm",
	[192158] = "Alarm",
	[192563] = "Alarm",
	[198745] = "Info",
	[198888] = "Alarm",
	[198931] = "Alarm",
	[198934] = "Alarm",
	[199210] = "Alarm",
	[199341] = "Alarm",
	[199726] = "Alarm",
	[199805] = {"Alert","Warning"},
	[210875] = "Alarm",
	[215430] = "Warning",
	[215433] = "Alarm",
})
