
BigWigs:AddColors("Hymdall", {
	[191284] = "Important",
	[193092] = "Attention",
	[193235] = {"Personal","Urgent"},
})

BigWigs:AddColors("Hyrja", {
	[191976] = {"Attention","Personal"},
	[192018] = "Important",
	[192048] = {"Attention","Personal"},
	[192307] = "Urgent",
	[200901] = "Urgent",
})

BigWigs:AddColors("Fenryr", {
	[196512] = "Important",
	[196543] = "Urgent",
	[196838] = {"Personal","Urgent"},
	[197556] = {"Attention","Personal"},
	["stages"] = "Neutral",
})

BigWigs:AddColors("God-King Skovald", {
	[193659] = {"Important","Personal"},
	[193668] = "Attention",
	[193702] = "Personal",
	[193826] = "Urgent",
})

BigWigs:AddColors("Odyn", {
	[197961] = {"Attention","Urgent"},
	[198077] = "Important",
	[198263] = "Important",
	[200988] = "Urgent",
	["warmup"] = "Neutral",
})

BigWigs:AddColors("Halls of Valor Trash", {
	[191508] = "Important",
	[192158] = "Important",
	[192563] = "Important",
	[198745] = "Attention",
	[198888] = "Important",
	[198931] = "Important",
	[198934] = "Important",
	[199210] = "Important",
	[199341] = "Important",
	[199726] = "Important",
	[199805] = {"Personal","Urgent"},
	[210875] = "Important",
	[215430] = {"Personal","Urgent"},
	[215433] = "Important",
})
