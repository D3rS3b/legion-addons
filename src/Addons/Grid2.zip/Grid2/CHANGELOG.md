# Grid2

## [2.0.44](https://github.com/michaelnpsp/Grid2/tree/2.0.44) (2022-06-04)
[Full Changelog](https://github.com/michaelnpsp/Grid2/compare/2.0.43...2.0.44) [Previous Releases](https://github.com/michaelnpsp/Grid2/releases)

- Retail TOC Updated  
- Fixing github issue #55 in Grid2 InsecureGroupHeaders code for classic and tbc.  
- Create build.yml  
- Fixing wrong translation in korean locale (wowace issue #1083)  
