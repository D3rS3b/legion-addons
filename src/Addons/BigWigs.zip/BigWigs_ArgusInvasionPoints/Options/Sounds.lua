
BigWigs:AddSounds("Matron Folnuna", {
	[247361] = "Alarm",
	[247379] = {"Long","Warning"},
	[247443] = "Alarm",
	[254147] = "Alert",
})

BigWigs:AddSounds("Mistress Alluradel", {
	[247517] = "Info",
	[247544] = "Alert",
	[247549] = "Warning",
	[247604] = "Alarm",
})

BigWigs:AddSounds("Inquisitor Meto", {
	[247492] = {"Alarm","Alert"},
	[247495] = {"Alert","Warning"},
	[247585] = {"Info","Long"},
	[247632] = "Alarm",
})

BigWigs:AddSounds("Sothanar", {
	[247410] = {"Alarm","Info","Warning"},
	[247416] = "Alert",
	[247437] = "Warning",
	[247698] = "Long",
})

BigWigs:AddSounds("Occularus", {
	[247318] = "Alarm",
	[247320] = "Warning",
	[247325] = "Info",
	[247332] = {"Alarm","Alert"},
	[247393] = {"Alarm","Long"},
})

BigWigs:AddSounds("Pit Lord Vilemus", {
	[247731] = "Long",
	[247733] = "Warning",
	[247739] = {"Alarm","Alert"},
})
