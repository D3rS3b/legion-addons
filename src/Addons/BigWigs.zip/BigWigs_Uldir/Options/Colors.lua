
BigWigs:AddColors("Taloc", {
	[270290] = {"blue","Personal"},
	[271224] = {"Personal","yellow"},
	[271296] = "red",
	[271728] = "orange",
	[271895] = "yellow",
	[271965] = "green",
	[275270] = {"blue","Personal"},
	[275432] = {"blue","Personal"},
	["stages"] = "green",
})

BigWigs:AddColors("MOTHER", {
	[267787] = {"Personal","red","yellow"},
	[267795] = {"blue","Personal","yellow"},
	[267878] = "red",
	[268198] = "orange",
	[268253] = {"blue","Personal","yellow"},
	[269051] = {"cyan","red"},
	[274205] = {"green","Personal"},
})

BigWigs:AddColors("Fetid Devourer", {
	[262277] = "red",
	[262288] = "orange",
	[262292] = "yellow",
	[262313] = {"orange","Personal"},
	[262314] = {"blue","Personal"},
	[262364] = {"cyan","red"},
	[262378] = "cyan",
})

BigWigs:AddColors("Zek'voz, Herald of N'zoth", {
	[-18397] = "cyan",
	[-18390] = "cyan",
	[264382] = {"Personal","yellow"},
	[265231] = "orange",
	[265248] = "cyan",
	[265360] = {"Personal","yellow"},
	[265530] = "red",
	[265662] = {"blue","Personal"},
	[267180] = "yellow",
	[267239] = "yellow",
	["stages"] = "green",
})

BigWigs:AddColors("Vectis", {
	[265178] = {"Personal","red"},
	[265212] = {"orange","Personal"},
	[265217] = "cyan",
	[266459] = "red",
	[267242] = "orange",
})

BigWigs:AddColors("Zul", {
	[269936] = {"blue","Personal"},
	[273288] = "yellow",
	[273350] = "orange",
	[273360] = "orange",
	[273365] = {"Personal","yellow"},
	[273451] = "red",
	[273889] = "cyan",
	[274168] = "green",
	[274271] = {"orange","Personal"},
	[274358] = {"Personal","red"},
	[276299] = "yellow",
})

BigWigs:AddColors("Mythrax the Unraveler", {
	[272115] = "orange",
	[272404] = "red",
	[272536] = {"Personal","yellow"},
	[273282] = {"Personal","red","yellow"},
	[273538] = "orange",
	[273810] = "yellow",
	[273949] = "red",
	[274230] = "green",
})

BigWigs:AddColors("G'huun", {
	[263235] = {"Personal","red"},
	[263307] = "orange",
	[263482] = "green",
	[267409] = "red",
	[267412] = "yellow",
	[267427] = "yellow",
	[267462] = "orange",
	[267509] = "cyan",
	[270287] = {"blue","Personal"},
	[270373] = "yellow",
	[270447] = {"Personal","red"},
	[272506] = {"orange","Personal"},
	[274582] = "red",
	[275160] = "orange",
	["stages"] = "cyan",
})

BigWigs:AddColors("Uldir Trash", {
	[276540] = "Important",
	[277047] = {"Attention","Personal"},
})
