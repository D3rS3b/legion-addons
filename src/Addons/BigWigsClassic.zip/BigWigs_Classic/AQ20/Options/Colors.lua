
BigWigs:AddColors("Kurinnaxx", {
	[25646] = {"Attention","Personal"},
	[25656] = "Urgent",
	[26527] = {"Important","Positive"},
})

BigWigs:AddColors("General Rajaxx", {
	["wave"] = "Urgent",
	[8269] = "Important",
	[25471] = {"Attention","Personal"},
})

BigWigs:AddColors("Moam", {
	[25685] = {"Attention","Urgent","Important"},
})

BigWigs:AddColors("Buru the Gorger", {
	[157168] = {"Attention","Personal"},
})

BigWigs:AddColors("Ayamiss the Hunter", {
	[25725] = {"Attention","Personal"},
	[8269] = {"Important","Positive"},
})

BigWigs:AddColors("Ossirian the Unscarred", {
	[25176] = {"Important","Attention","Urgent"},
	["debuff"] = "Attention",
})

BigWigs:AddColors("Ruins of Ahn'Qiraj Trash", {
	[8269] = "Important",
	[25698] = "Urgent",
	[8732] = "Neutral",
	["warrior"] = "Positive",
	[26556] = {"Attention","Personal"},
	["guard"] = "Positive",
	[24340] = "Neutral",
})
