
BigWigs:AddSounds("Kurinnaxx", {
	[25656] = "Alert",
})

BigWigs:AddSounds("Ossirian the Unscarred", {
	["debuff"] = "Info",
})

BigWigs:AddSounds("Ruins of Ahn'Qiraj Trash", {
	[8269] = "Long",
	[25698] = "Alert",
})
