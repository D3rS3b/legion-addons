
BigWigs:AddColors("Razorgore the Untamed", {
	[23023] = {"Urgent","Personal"},
	["stages"] = {"Urgent","Important"},
	[14515] = {"Important","Personal"},
	["eggs"] = "Positive",
})

BigWigs:AddColors("Vaelastrasz the Corrupt", {
	[18173] = {"Attention","Personal"},
})

BigWigs:AddColors("Broodlord Lashlayer", {
	[40220] = {"Attention","Personal"},
})

BigWigs:AddColors("Firemaw", {
	[23339] = {"Important","Urgent"},
	[22539] = "Important",
})

BigWigs:AddColors("Ebonroc", {
	[23339] = {"Important","Urgent"},
	[22539] = "Important",
	[23340] = {"Attention","Personal"},
})

BigWigs:AddColors("Flamegor", {
	[23339] = {"Important","Urgent"},
	[22539] = "Important",
	[23342] = "Urgent",
})

BigWigs:AddColors("Chromaggus", {
	[23537] = {"Important","Neutral"},
	["breath"] = {"Positive","Attention","Important"},
	[23128] = "Attention",
	["debuffs"] = {"Important","Urgent"},
})

BigWigs:AddColors("Nefarian ", {
	["otherwarn"] = "Important",
	[22539] = "Attention",
	["classcall"] = {"Positive","Important"},
	[22686] = {"Urgent","Important"},
})
