
BigWigs:AddSounds("Razorgore the Untamed", {
	[14515] = "Alert",
	[23023] = "Info",
})

BigWigs:AddSounds("Vaelastrasz the Corrupt", {
	[18173] = "Alarm",
})

BigWigs:AddSounds("Chromaggus", {
	["debuffs"] = {"Alarm","Warning"},
})

BigWigs:AddSounds("Nefarian ", {
	[22686] = "Alert",
	[22539] = "Alert",
})
