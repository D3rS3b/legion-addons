
BigWigs:AddColors("The Prophet Skeram", {
	[785] = {"Attention","Personal"},
	[26192] = "Urgent",
	[20449] = "Important",
	["images"] = {"Important","Positive"},
})

BigWigs:AddColors("The Bug Trio", {
	[25786] = "Personal",
	[26580] = {"Important","Urgent"},
	[25807] = "Urgent",
	[25812] = "Attention",
})

BigWigs:AddColors("Battleguard Sartura", {
	["stages"] = "Positive",
	[26083] = {"Important","Positive"},
	[8269] = {"Urgent","Attention"},
})

BigWigs:AddColors("Fankriss the Unyielding", {
	[25832] = "Urgent",
	[720] = {"Important","Personal"},
	[25646] = {"Attention","Personal"},
})

BigWigs:AddColors("Viscidus", {
	[25991] = "Attention",
	[25989] = "Personal",
	["freeze"] = {"Positive","Neutral","Important","Urgent"},
})

BigWigs:AddColors("Princess Huhuran", {
	[26051] = "Attention",
	["berserk"] = {"Urgent","Important"},
	[26180] = {"Positive","Important","Personal"},
})

BigWigs:AddColors("The Twin Emperors", {
	[7393] = "Important",
	[802] = "Neutral",
	[26607] = "Personal",
	[800] = {"Urgent","Important","Attention"},
})

BigWigs:AddColors("Ouro", {
	[26103] = "Important",
	[26615] = {"Urgent","Positive"},
	["stages"] = {"Attention","Important"},
	[26102] = {"Attention","Important"},
	["scarab"] = "Important",
})

BigWigs:AddColors("C'Thun", {
	["weakened"] = {"Positive","Urgent","Important"},
	[26029] = {"Urgent","Important"},
	["stages"] = {"Attention","Neutral"},
	["tentacle"] = {"Urgent","Important"},
})

BigWigs:AddColors("Ahn'Qiraj Trash", {
	[8269] = "Important",
	[25698] = "Urgent",
	[25051] = {"Attention","Personal"},
	[26554] = "Neutral",
	["warrior"] = "Positive",
	[26556] = {"Attention","Personal"},
	["guard"] = "Positive",
	[26558] = "Neutral",
})
