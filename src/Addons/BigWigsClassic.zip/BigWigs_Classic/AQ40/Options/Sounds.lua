
BigWigs:AddSounds("The Prophet Skeram", {
	["images"] = "Long",
})

BigWigs:AddSounds("The Bug Trio", {
	[25786] = "Alarm",
})

BigWigs:AddSounds("Battleguard Sartura", {
	[8269] = "Long",
	[26083] = "Alert",
})

BigWigs:AddSounds("Fankriss the Unyielding", {
	[25832] = "Info",
	[720] = "Alert",
})

BigWigs:AddSounds("Viscidus", {
	[25989] = "Alarm",
})

BigWigs:AddSounds("Princess Huhuran", {
	[26051] = "Warning",
})

BigWigs:AddSounds("The Twin Emperors", {
	[7393] = "Warning",
	[26607] = "Alarm",
	[800] = "Info",
})

BigWigs:AddSounds("Ouro", {
	[26615] = "Long",
})

BigWigs:AddSounds("Ahn'Qiraj Trash", {
	[8269] = "Long",
	[25698] = "Alert",
})
