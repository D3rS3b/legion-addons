
BigWigs:AddColors("Lucifron", {
	[19703] = "Attention",
	[20604] = {"Attention","Personal"},
	[19702] = "Important",
})

BigWigs:AddColors("Magmadar", {
	[19451] = "Attention",
	[19428] = "Personal",
	[19408] = "Positive",
})

BigWigs:AddColors("Gehennas", {
	[19716] = {"Urgent","Attention"},
	[19717] = "Personal",
})

BigWigs:AddColors("Baron Geddon", {
	[19695] = "Important",
	[20478] = "Urgent",
	[20475] = "Personal",
})

BigWigs:AddColors("Shazzrah", {
	[23138] = "Important",
	[19714] = "Urgent",
	[19715] = "Attention",
})

BigWigs:AddColors("Sulfuron Harbinger", {
	[19779] = "Attention",
	[19775] = "Important",
})

BigWigs:AddColors("Majordomo Executus", {
	[20619] = {"Important","Urgent"},
	[21075] = {"Important","Urgent"},
})

BigWigs:AddColors("Ragnaros ", {
	["emerge"] = {"Attention","Urgent","Positive"},
	[20566] = "Important",
	["submerge"] = {"Attention","Urgent"},
})
