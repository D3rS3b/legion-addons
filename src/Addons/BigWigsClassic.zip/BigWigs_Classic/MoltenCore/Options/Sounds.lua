
BigWigs:AddSounds("Magmadar", {
	[19451] = "Info",
	[19428] = "Alert",
})

BigWigs:AddSounds("Gehennas", {
	[19717] = "Alarm",
})

BigWigs:AddSounds("Baron Geddon", {
	[20475] = "Alarm",
	[19695] = "Long",
})

BigWigs:AddSounds("Shazzrah", {
	[19714] = "Alarm",
	[19715] = "Info",
})

BigWigs:AddSounds("Majordomo Executus", {
	[20619] = "Info",
	[21075] = "Info",
})

BigWigs:AddSounds("Ragnaros ", {
	["submerge"] = {"Alarm","Long"},
	["emerge"] = {"Long","Alarm"},
})
