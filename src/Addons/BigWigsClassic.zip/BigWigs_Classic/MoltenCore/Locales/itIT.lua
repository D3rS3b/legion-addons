local L = BigWigs:NewBossLocale("Lucifron", "itIT")
if not L then return end
if L then
	--L.mc_bar = "MC: %s"
end

L = BigWigs:NewBossLocale("Majordomo Executus", "itIT")
if L then
	--L.disabletrigger = "Impossible! Stay your attack, mortals... I submit! I submit!"
	--L.power_next = "Next Power"
end

L = BigWigs:NewBossLocale("Ragnaros ", "itIT")
if L then
	--L.engage_trigger = "NOW FOR YOU,"
	--L.submerge_trigger = "COME FORTH,"

	--L.knockback_message = "Knockback!"
	--L.knockback_bar = "Knockback"

	--L.submerge = "Submerge"
	--L.submerge_desc = "Warn for Ragnaros' submerge."
	--L.submerge_message = "Ragnaros down for 90 sec!"
	--L.submerge_bar = "Submerge"

	--L.emerge = "Emerge"
	--L.emerge_desc = "Warn for Ragnaros' emerge."
	--L.emerge_message = "Ragnaros emerged, 3 mins until submerge!"
	--L.emerge_bar = "Emerge"
end

