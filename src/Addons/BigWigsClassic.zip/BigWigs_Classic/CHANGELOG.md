# BigWigs [Classic]

## [v7.3.1](https://github.com/BigWigsMods/BigWigs_Classic/tree/v7.3.1) (2018-03-15)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_Classic/compare/v7.3.0...v7.3.1)

- Fill in options data for repo users.  
- Add color & sound files  
- Update travis file  
- Swap to using LoadOn-InstanceId  
- Use instance ids in :NewBoss.  
- BlackwingLair/Chromaggus: Fix comments  
- Cleanups  
- Remove BOM from .lua files (#5)  
- Update travis file  
