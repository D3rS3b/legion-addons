All textures here are custom made for KuiNameplates by Kesava @ curse.com unless otherwise noted.
