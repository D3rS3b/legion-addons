# Capping

## [v7.3.3](https://github.com/BigWigsMods/Capping/tree/v7.3.3) (2018-04-03)
[Full Changelog](https://github.com/BigWigsMods/Capping/compare/v7.3.2...v7.3.3)

- update metadata  
- Add 2 missing locales (koKR) (#9)  
